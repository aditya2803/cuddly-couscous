#include "threadpool.h"

#include <iostream>

class store { 

};

int main(int argc, char** argv) {
	std::cout << "I 'm not ready yet!" << std::endl;
	return EXIT_SUCCESS;
}

